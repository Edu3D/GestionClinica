package servicios;

import java.util.List;

import clinica.modelos.Cita;
import clinica.modelos.Paciente;

public interface IRecepcionistaServicios {

	public Paciente buscarPacientePorID();
	public List<Cita> ListarCitas();
	public void addCita(Cita cita);
	public void editCita(Cita cita);
	public void delCita(Cita cita);
	
}
