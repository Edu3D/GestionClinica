package servicios.imp;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import clinica.basedatos.Conexion;
import clinica.modelos.Cita;
import clinica.modelos.Especialidad;
import clinica.modelos.Medico;
import clinica.modelos.Paciente;
import servicios.IRecepcionistaServicios;

public class RecepcionistaServicios implements IRecepcionistaServicios {
	private Connection con;

	@Override
	public Paciente buscarPacientePorID() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cita> ListarCitas() {
		List<Cita> citas = new ArrayList<>();
		Cita cita;
		con = new Conexion().getConnection();

		try {
			PreparedStatement visualiza = (PreparedStatement) con
					.prepareStatement("select p.apellidos as apellidosP, p.direccion as direccionP, "
							+ "p.dni as dniP, p.fechaNacimiento as fechaNacimientoP, p.idPaciente as idP,"
							+ "p.nombre as nombreP, p.observaciones as observacionesP, p.telefono as telfP,"
							+ " m.apellidos as apellidosM, m.direccion as direccionM, m.dni as dniM, "
							+ "m.fechaNacimiento as fechaNacimientoM, m.idMedico as idM, m.nombre as nombreM, "
							+ "m.telefono as telfM, c.fecha as fechaC, e.idEspecialidad as idE,e.nombre as nombreE "
							+ "from citas as c inner join pacientes as p on c.idPaciente = p.idPaciente "
							+ "inner join medicos as m on c.idMedico = m.idMedico "
							+ "inner join especialidades as e on m.especialidad = e.idEspecialidad; ");

			ResultSet resultado;
			resultado = visualiza.executeQuery();

			while (resultado.next()) {
				cita = new Cita();
				Medico medico = new Medico();
				Paciente paciente = new Paciente();
				Especialidad especialidad = new Especialidad();

				especialidad.setIdEspecialidad(resultado.getInt("idE"));
				especialidad.setNombre(resultado.getString("nombreE"));

				medico.setEspecialidad(especialidad);
				medico.setApellidos(resultado.getString("apellidosM"));
				medico.setNombre(resultado.getString("nombreM"));
				medico.setDireccion(resultado.getString("direccionM"));
				medico.setDni(resultado.getString("dniM"));
				medico.setFechaNacimiento(String.valueOf(resultado.getDate("fechaNacimientoM")));
				medico.setIdMedico(resultado.getInt("idM"));
				medico.setTelefono(resultado.getString("telfM"));

				paciente.setApellidos(resultado.getString("apellidosP"));
				paciente.setNombre(resultado.getString("nombreP"));
				paciente.setDireccion(resultado.getString("direccionP"));
				paciente.setDni(resultado.getString("dniP"));
				paciente.setFechaNacimiento(String.valueOf(resultado.getDate("fechaNacimientoP")));
				paciente.setIdPaciente(resultado.getInt("idP"));
				paciente.setTelefono(resultado.getString("telfP"));
				paciente.setObservaciones(resultado.getString("observacionesP"));

				cita.setFecha(String.valueOf(resultado.getDate("fechaC")));
				cita.setMedico(medico);
				cita.setPaciente(paciente);

				citas.add(cita);
			}

			return citas;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			Conexion.disconnection();
		}
	}

	@Override
	public void addCita(Cita cita) {
		con = new Conexion().getConnection();
		Paciente paciente = new Paciente();
		paciente = cita.getPaciente();
		try {
			String insertPaciente = "INSERT INTO `pacientes`"
					+ "(`nombre`, `apellidos`, `dni`, `fechaNacimiento`, `telefono`, `direccion`, `observaciones`) "
					+ "VALUES (?,?,?,?,?,?,?);";

			PreparedStatement pst = con.prepareStatement(insertPaciente);
			pst.setString(1, paciente.getNombre());
			pst.setString(2, paciente.getApellidos());
			pst.setString(3, paciente.getDni());
			pst.setDate(4, Date.valueOf((paciente.getFechaNacimiento())));
			pst.setString(5, paciente.getTelefono());
			pst.setString(6, paciente.getDireccion());
			pst.setString(7, paciente.getObservaciones());

			pst.executeUpdate();

			String insertCita = "INSERT INTO `citas`" + "(`idPaciente`, `fecha`, `idMedico`) " + "VALUES (?,?,?);";

			PreparedStatement pst_2 = con.prepareStatement(insertCita);
			pst_2.setInt(1, paciente.getIdPaciente());
			pst_2.setDate(2, Date.valueOf(cita.getFecha()));
			pst_2.setInt(3, cita.getMedico().getIdMedico());

			pst_2.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Conexion.disconnection();
		}
	}

	@Override
	public void editCita(Cita cita) {
		con = new Conexion().getConnection();
		try {
			String updateCita = "UPDATE `citas` SET `fecha`=? WHERE idPaciente = ? AND idMedico =?;";

			PreparedStatement pst = con.prepareStatement(updateCita);
			pst.setDate(1, Date.valueOf((cita.getFecha())));
			pst.setInt(2, cita.getPaciente().getIdPaciente());
			pst.setInt(3, cita.getMedico().getIdMedico());
			
			pst.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Conexion.disconnection();
		}
	}

	@Override
	public void delCita(Cita cita) {
		con = new Conexion().getConnection();
		try {
			String delete = "DELETE FROM `citas` WHERE idPaciente = ? AND idMedico = ?;";

			PreparedStatement pst = con.prepareStatement(delete);
			pst.setInt(1, cita.getPaciente().getIdPaciente());
			pst.setInt(2, cita.getMedico().getIdMedico());
			
			pst.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Conexion.disconnection();
		}

	}

}
