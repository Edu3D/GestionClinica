package servicios;

import java.util.List;

import clinica.modelos.Cita;
import clinica.modelos.Paciente;

public interface IMedicoServicios {
	
	public Paciente buscarPacientePorID();
	public List<Cita> ListarCitas(String dni);
}
