package serviciosMYSQL.imp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import clinica.basedatos.ConexionMySql;
import clinica.modelos.Cita;
import clinica.modelos.Especialidad;
import clinica.modelos.Medico;
import clinica.modelos.Paciente;
import serviciosMYSQL.IMedicoServicios;

public class MedicoServicios implements IMedicoServicios {

	private Connection con;

	@Override
	public Paciente buscarPacientePorID() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cita> ListarCitas(String dni) {
		List<Cita> citas = new ArrayList<>();
		Cita cita;
		con = new ConexionMySql().getConnection();

		try {
			PreparedStatement visualiza = (PreparedStatement) con.prepareStatement(
					"select p.apellidos as apellidosP, p.direccion as direccionP, "
					+ "p.dni as dniP, p.fechaNacimiento as fechaNacimientoP, p.idPaciente as idP,"
					+ "p.nombre as nombreP, p.observaciones as observacionesP, p.telefono as telfP,"
					+ " m.apellidos as apellidosM, m.direccion as direccionM, m.dni as dniM, "
					+ "m.fechaNacimiento as fechaNacimientoM, m.idMedico as idM, m.nombre as nombreM, "
					+ "m.telefono as telfM, c.fecha as fechaC, e.idEspecialidad as idE,e.nombre as nombreE "
					+ "from citas as c inner join pacientes as p on c.idPaciente = p.idPaciente "
					+ "inner join medicos as m on c.idMedico = m.idMedico "
					+ "inner join especialidades as e on m.especialidad = e.idEspecialidad "
					+ "where m.dni = ?; ");
			visualiza.setString(1, dni);
			
			ResultSet resultado;
			resultado = visualiza.executeQuery();

			while (resultado.next()) {
				cita = new Cita();
				Medico medico = new Medico();
				Paciente paciente = new Paciente();
				Especialidad especialidad = new Especialidad();
				
				especialidad.setIdEspecialidad(resultado.getInt("idE"));
				especialidad.setNombre(resultado.getString("nombreE"));
				
				medico.setEspecialidad(especialidad);
				medico.setApellidos(resultado.getString("apellidosM"));
				medico.setNombre(resultado.getString("nombreM"));
				medico.setDireccion(resultado.getString("direccionM"));
				medico.setDni(resultado.getString("dniM"));
				medico.setFechaNacimiento(String.valueOf(resultado.getDate("fechaNacimientoM")));
				medico.setIdMedico(resultado.getInt("idM"));
				medico.setTelefono(resultado.getString("telfM"));
				
				paciente.setApellidos(resultado.getString("apellidosP"));
				paciente.setNombre(resultado.getString("nombreP"));
				paciente.setDireccion(resultado.getString("direccionP"));
				paciente.setDni(resultado.getString("dniP"));
				paciente.setFechaNacimiento(String.valueOf(resultado.getDate("fechaNacimientoP")));
				paciente.setIdPaciente(resultado.getInt("idP"));
				paciente.setTelefono(resultado.getString("telfP"));
				paciente.setObservaciones(resultado.getString("observacionesP"));
				
				cita.setFecha(String.valueOf(resultado.getDate("fechaC")));
				cita.setMedico(medico);
				cita.setPaciente(paciente);
				
				citas.add(cita);
			}
			
			return citas;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			ConexionMySql.disconnection();
		}
	}

}
