package serviciosMYSQL.imp;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clinica.basedatos.ConexionMySql;
import serviciosMYSQL.IUsuarioServicios;

public class UsuarioServicios implements IUsuarioServicios {
	private Connection con;
	private String user = "", pass = "";
	@Override
	public boolean checkUserAndPassword(String idUsuario, String pass2) {
	
		con = new ConexionMySql().getConnection();

		try {
			PreparedStatement visualiza = (PreparedStatement) con.prepareStatement(
					"SELECT u.nombreUsuario as nombreU, u.pass as pass from users as u where nombreUsuario = ? and pass = ? ");
			visualiza.setString(1, idUsuario);
			visualiza.setString(2, pass2);
			ResultSet resultado;
			resultado = visualiza.executeQuery();
			while (resultado.next()) {
				
				user = resultado.getString("nombreU");
				pass = resultado.getString("pass");
		
			}
			if(user.isEmpty() || pass.isEmpty()){
				return false;
			}else{
				return true;
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			ConexionMySql.disconnection();
		}
	}

	@Override
	public String checkTipoUser(String user, String pass) {
		String tipoUser = "";
		con = new ConexionMySql().getConnection();

		try {
			PreparedStatement visualiza = (PreparedStatement) con.prepareStatement(
					"SELECT tipoUsuario as tu from users as u where nombreUsuario = ? and pass = ? ");
			visualiza.setString(1, user);
			visualiza.setString(2, pass);
			ResultSet resultado;
			resultado = visualiza.executeQuery();
			while (resultado.next()) {
				
				tipoUser = resultado.getString("tu");
				
		
			}
			return tipoUser;
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			ConexionMySql.disconnection();
		}
	}

}
