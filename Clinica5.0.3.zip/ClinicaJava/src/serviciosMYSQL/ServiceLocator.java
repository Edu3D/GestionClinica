package serviciosMYSQL;

import serviciosMYSQL.imp.DirectorServicios;
import serviciosMYSQL.imp.MedicoServicios;
import serviciosMYSQL.imp.RecepcionistaServicios;
import serviciosMYSQL.imp.UsuarioServicios;

public class ServiceLocator {

	private static IUsuarioServicios usuarioServicios = new UsuarioServicios();
	private static IMedicoServicios medicoServicios = new MedicoServicios();
	private static IDirectorServicios directorServicios = new DirectorServicios();
	private static IRecepcionistaServicios recepcionistaServicios = new RecepcionistaServicios();

	private ServiceLocator() {
	}

	public static IMedicoServicios getMedicoServicios() {
		return medicoServicios;
	}

	public static IDirectorServicios getDirectorServicios() {
		return directorServicios;
	}

	public static IRecepcionistaServicios getRecepcionistaServicios() {
		return recepcionistaServicios;
	}

	public static IUsuarioServicios getUsuarioServicios() {
		return usuarioServicios;
	}

}
