package serviciosMYSQL;

public interface IUsuarioServicios {

	public boolean checkUserAndPassword (String idUsuario, String pass);
	
	public String checkTipoUser(String user, String pass);
	
	
}
