package serviciosMYSQL;
import java.util.List;

import clinica.modelos.Cita;
import clinica.modelos.Paciente;

public interface IRecepcionistaServicios {

	public Paciente buscarPacientePorID();
	public List<Cita> ListarCitas();
	public void addCita(Cita cita);
	public void modCita(Cita cita);
	public void eliminarCita(Cita cita);
	
}
