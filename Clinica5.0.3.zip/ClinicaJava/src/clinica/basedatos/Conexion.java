package clinica.basedatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

	private final static String URL = "jdbc:ucanaccess://bd/clinicadb.accdb";
	private String user = "root";
	private String pass = "";
	private static Connection con;

	public Conexion(String user, String pass) {
		this.user = user;
		this.pass = pass;
	}
	public Conexion(){
		
	}

	public Connection getConnection() {
		con = null;
		try {Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			con = (Connection) DriverManager.getConnection(URL, user, pass);
			return con;

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void disconnection() {
		try {
			if (!con.isClosed())
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}