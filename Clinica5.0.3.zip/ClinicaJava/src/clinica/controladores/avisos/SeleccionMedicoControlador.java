package clinica.controladores.avisos;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class SeleccionMedicoControlador implements Initializable {

	@FXML
	private ImageView imgAdvice;

	@FXML
	private Button aceptarAvisoButton;


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		imgAdvice.setImage(new Image("/Imagenes/warning-icon.png"));

	}
	
	@FXML
	private void onAceptarButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
}
