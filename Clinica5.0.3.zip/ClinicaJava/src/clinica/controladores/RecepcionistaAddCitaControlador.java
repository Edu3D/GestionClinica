package clinica.controladores;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import clinica.modelos.Cita;
import clinica.modelos.Medico;
import clinica.modelos.Paciente;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import serviciosMYSQL.ServiceLocator;

public class RecepcionistaAddCitaControlador implements Initializable {

	@FXML
	private Button nextButton;
	@FXML
	private Button cancelButton;
	@FXML
	private Button backButton;
	@FXML
	private Button finishButton;

	@FXML
	private TextField patientNameText;

	@FXML
	private TextField patientLastNameText;

	@FXML
	private TextField patientDNIText;

	@FXML
	private TextField patientPhoneText;

	@FXML
	private TextField patientAddressText;

	@FXML
	private TextArea patientObsArea;

	@FXML
	private DatePicker patientDatePicker;

	@FXML
	private ComboBox<Medico> especialistaBox;

	private Scene addCitaUnoScene;

	private Stage stage;

	private String nombre = "";
	private String apellidos = "";
	private String dni = "";
	private String fecha = "";
	private String telefono = "";
	private String direcion ="";
	private String observacion= "";

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		System.out.println(arg0 +" ***** "+ arg1);
	}

	private void cargarEscpecialistas() {

		especialistaBox.setItems(FXCollections.observableArrayList(ServiceLocator.getDirectorServicios().listarMedicos()));
	}

	@FXML
	private void onAddButton(ActionEvent event) {
		cargarScenaDos();
		stage.show();

	}

	@FXML
	private void onDelButton(ActionEvent event) {
	}

	@FXML
	private void onEditButton(ActionEvent event) {
	}

	@FXML
	private void onSigButton(ActionEvent event) {

		nombre = patientNameText.getText();
		apellidos = patientLastNameText.getText();
		dni = patientDNIText.getText();
		telefono = patientPhoneText.getText();
		direcion = patientAddressText.getText();
		fecha = patientDatePicker.getValue().toString();
		observacion = patientObsArea.getText();
		cargarScenaDos();
		cargarEscpecialistas();
		stage.show();
	}

	@FXML
	private void onCancelarButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

	@FXML
	private void onAtrasButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		stage = (Stage) source.getScene().getWindow();
		stage.hide();

		patientNameText.setText(nombre);
		patientLastNameText.setText(apellidos);
		patientDNIText.setText(dni);
		patientPhoneText.setText(telefono);
		patientAddressText.setText(direcion);
		patientDatePicker.setValue(LocalDate.parse(fecha));
		patientObsArea.setText(observacion);

	}

	@FXML
	private void onFinishButton(ActionEvent event) {
		// TODO EL SERVICE LOCATOR SE ENCARGA
	}

	private void cargarScenaDos() {
		try {
			stage = new Stage();
			stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					stage.close();
				}
			});
			addCitaUnoScene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/Add_Cita_2.fxml")).load());

			stage.setScene(addCitaUnoScene);
			stage.setTitle("Datos De La Cita");
			stage.setResizable(false);
			stage.initModality(Modality.APPLICATION_MODAL);
		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}
	}
}
