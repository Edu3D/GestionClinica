package clinica.controladores;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import clinica.modelos.Especialidad;
import clinica.modelos.Medico;
import clinica.modelos.MedicoSeleccionado;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import serviciosMYSQL.ServiceLocator;

public class DirectorMedicoEditControlador implements Initializable {

	@FXML
	private Button cancelButton;
	@FXML
	private Button aceptarButton;

	@FXML
	private TextField patientNameText;

	@FXML
	private TextField patientLastNameText;

	@FXML
	private TextField patientDNIText;

	@FXML
	private TextField patientPhoneText;

	@FXML
	private TextField patientAddressText;

	@FXML
	private DatePicker patientDatePicker;

	@FXML
	private ComboBox<Especialidad> especialidadComboBox;

	@FXML
	private Label errorLabel;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		patientNameText.setText(MedicoSeleccionado.getPacienteSelecionado().getNombre());
		patientDNIText.setText(MedicoSeleccionado.getPacienteSelecionado().getDni());
		patientLastNameText.setText(MedicoSeleccionado.getPacienteSelecionado().getApellidos());
		patientDatePicker.setValue(LocalDate.parse((MedicoSeleccionado.getPacienteSelecionado().getFechaNacimiento())));
		patientAddressText.setText(MedicoSeleccionado.getPacienteSelecionado().getDireccion());
		patientPhoneText.setText(MedicoSeleccionado.getPacienteSelecionado().getTelefono());

		especialidadComboBox.setItems(
				FXCollections.observableArrayList(ServiceLocator.getDirectorServicios().listarEspecialidad()));
		especialidadComboBox.getSelectionModel().select(MedicoSeleccionado.getPacienteSelecionado().getEspecialidad());

	}

	@FXML
	private void onAceptarAddButton(ActionEvent event) {

		if (patientNameText.getText().isEmpty()) {
			patientNameText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
		} else {
			patientNameText.setStyle("");
			errorLabel.setText("");
		}
		if (patientLastNameText.getText().isEmpty()) {
			patientLastNameText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
		} else {
			patientNameText.setStyle("");
			errorLabel.setText("");
		}
		if (patientDNIText.getText().isEmpty()) {
			patientDNIText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
		} else {
			patientNameText.setStyle("");
			errorLabel.setText("");
		}
		if (patientDatePicker.getValue() == null || patientDatePicker.getValue().toString().isEmpty()) {
			patientDatePicker.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
		} else {
			patientNameText.setStyle("");
			errorLabel.setText("");
		}
		if (patientPhoneText.getText().isEmpty()) {
			patientPhoneText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
		} else {
			patientNameText.setStyle("");
			errorLabel.setText("");
		}
		if (patientAddressText.getText().isEmpty()) {
			patientAddressText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
		} else {
			patientNameText.setStyle("");
			errorLabel.setText("");
		}
		if (errorLabel.getText().isEmpty()) {
			Medico medico = MedicoSeleccionado.getPacienteSelecionado();
			medico.setApellidos(patientLastNameText.getText());
			medico.setNombre(patientNameText.getText());
			medico.setDni(patientDNIText.getText());
			medico.setDireccion(patientAddressText.getText());
			medico.setTelefono(patientPhoneText.getText());
			medico.setFechaNacimiento(String.valueOf(patientDatePicker.getValue()));
			System.out.println(String.valueOf(patientDatePicker.getValue()));
			medico.setEspecialidad(especialidadComboBox.getValue());
			ServiceLocator.getDirectorServicios().editMedico(medico);

			Node source = (Node) event.getSource();
			Stage stage = (Stage) source.getScene().getWindow();
			stage.close();
		}
	}

	@FXML
	private void onCancelarButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
}
