package clinica.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import clinica.modelos.Cita;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import serviciosMYSQL.ServiceLocator;

public class RecepcionistaControlador implements Initializable {

	@FXML
	private TableView<Cita> citasTable;

	@FXML
	private TableColumn<Cita, String> nombreCell;

	@FXML
	private TableColumn<Cita, String> dniCell;

	@FXML
	private TableColumn<Cita, String> fechaCell;

	@FXML
	private TableColumn<Cita, String> especialistaCell;

	@FXML
	private Button addButton;
	@FXML
	private Button editButton;
	@FXML
	private Button delButton;
	private Scene addCitaUnoScene;

	private Stage stage;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		stage = new Stage();

		citasTable
				.setItems(FXCollections.observableArrayList(ServiceLocator.getRecepcionistaServicios().ListarCitas()));

		nombreCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("nombre"));
		dniCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("DNI"));
		fechaCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("Fecha"));
		especialistaCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("Especialista"));

	}

	@FXML
	private void onAddButton(ActionEvent event) {
		cargarScenaUno();
		stage.show();

	}

	@FXML
	private void onDelButton(ActionEvent event) {
	}

	@FXML
	private void onEditButton(ActionEvent event) {
	}
	
	@FXML
	private void onCancelarButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

	private void cargarScenaUno() {
		try {

			stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					stage.close();
				}
			});

			addCitaUnoScene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/Add_Cita_1.fxml")).load());
			stage.setScene(addCitaUnoScene);
			stage.setResizable(false);
			stage.setTitle("Datos Del Paciente");
			if (stage.getModality() == Modality.APPLICATION_MODAL){
				
			}else
			stage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}
	}
}
