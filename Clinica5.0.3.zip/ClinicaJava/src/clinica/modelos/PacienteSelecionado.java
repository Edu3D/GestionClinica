package clinica.modelos;

public class PacienteSelecionado {
	private static Paciente paciente;

	private PacienteSelecionado() {
	}

	public static synchronized Paciente getPacienteSelecionado() {
		return paciente;
	}

	public static synchronized void setPacienteSelecionado(Paciente paciente2) {
		paciente = paciente2;
	}
}
