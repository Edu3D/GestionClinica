package clinica.modelos;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Especialidad {
	
	private SimpleStringProperty nombre = new SimpleStringProperty("");
	private SimpleIntegerProperty idEspecialidad = new SimpleIntegerProperty();
	public String getNombre() {
		return nombre.get();
	}
	public void setNombre(String nombre) {
		this.nombre.set(nombre);
	}
	public Integer getIdEspecialidad() {
		return idEspecialidad.get();
	}
	public void setIdEspecialidad(Integer idEspecialidad) {
		this.idEspecialidad.set(idEspecialidad);
	}
	@Override
	public String toString() {
		return getNombre();
	}
}
