package clinica.modelos;

import javafx.beans.property.SimpleStringProperty;

public class Cita {
	private Medico medico;
	private Paciente paciente;
	private SimpleStringProperty fecha = new SimpleStringProperty("");

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico nombre) {
		this.medico = nombre;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public String getFecha() {
		return fecha.get();
	}

	public void setFecha(String fecha) {
		this.fecha.set(fecha);
	}
	@Override
	public String toString() {
		return getFecha()+ " " +getPaciente();
	}

}
