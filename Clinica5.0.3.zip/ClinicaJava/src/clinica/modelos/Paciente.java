package clinica.modelos;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Paciente extends Persona {

	private SimpleIntegerProperty idPaciente = new SimpleIntegerProperty();

	private SimpleStringProperty Observaciones = new SimpleStringProperty("");

	public Integer getIdPaciente() {
		return idPaciente.get();
	}

	public void setIdPaciente(Integer idPaciente) {
		this.idPaciente.set(idPaciente);
	}

	public String getObservaciones() {
		return Observaciones.get();
	}

	public void setObservaciones(String observaciones) {
		Observaciones.set(observaciones);
	}
}
