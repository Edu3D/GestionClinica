package serviciosMYSQL;

import java.sql.SQLException;
import java.util.List;

import clinica.modelos.Cita;
import clinica.modelos.Especialidad;
import clinica.modelos.Medico;
import clinica.modelos.Paciente;

public interface IDirectorServicios {
	public Paciente buscarPacientePorID();
	public List<Cita> listarCitas();
	public List<Paciente> listarPacientes();
	public List<Medico> listarMedicos();
	public Integer cuantosCampos();
	public List<String> nombreCamposTablaMedicos();
	public List<String> nombreCamposTablaPacientes();
	public void addPaciente(Paciente paciente);
	public List<Especialidad> listarEspecialidad();
	public void delPaciente(Paciente paciente);
	public void editPaciente(Paciente paciente);
	public void addMedico(Medico medico) throws SQLException;
	public void delMedico(Medico medico);
	public void editMedico(Medico medico);
	public void addCita(Cita cita);
	public void delCita(Cita cita);
	public void editCita(Cita cita);
}
