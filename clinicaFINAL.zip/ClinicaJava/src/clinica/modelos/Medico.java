package clinica.modelos;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Medico extends Persona {
	private SimpleIntegerProperty idMedico = new SimpleIntegerProperty();
	private Especialidad especialidad;
	private SimpleStringProperty tipoUsuario = new SimpleStringProperty();

	public Integer getIdMedico() {
		return idMedico.get();
	}

	public void setIdMedico(Integer idMedico) {
		this.idMedico.set(idMedico);
	}

	public Especialidad getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(Especialidad especialidad) {
		this.especialidad = especialidad;
	}

	public String getTipoUsuario() {
		return tipoUsuario.get();
	}

	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario.set(tipoUsuario);
	}
}