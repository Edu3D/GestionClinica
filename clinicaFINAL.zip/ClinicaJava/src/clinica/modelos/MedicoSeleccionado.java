package clinica.modelos;

public class MedicoSeleccionado {
	private static Medico medico;

	private MedicoSeleccionado() {
	}

	public static synchronized Medico getPacienteSelecionado() {
		return medico;
	}

	public static synchronized void setPacienteSelecionado(Medico medico2) {
		medico = medico2;
	}
}
