
package clinica.modelos;

public class CitaSeleccionada {
	private static Cita cita;

	private CitaSeleccionada() {
	}

	public static synchronized Cita getCitaSelecionado() {
		return cita;
	}

	public static synchronized void setCitaSelecionado(Cita cita2) {
		cita = cita2;
	}
}
