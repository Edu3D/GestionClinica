package clinica.modelos;

import javafx.beans.property.SimpleStringProperty;

public class Persona {

	private SimpleStringProperty nombre = new SimpleStringProperty("");
	private SimpleStringProperty apellidos = new SimpleStringProperty("");
	private SimpleStringProperty dni = new SimpleStringProperty("");
	private SimpleStringProperty fechaNacimiento = new SimpleStringProperty("");
	private SimpleStringProperty telefono = new SimpleStringProperty("");
	private SimpleStringProperty direccion = new SimpleStringProperty("");

	public String getNombre() {
		return nombre.get();
	}

	public void setNombre(String nombre) {
		this.nombre.set(nombre);
	}

	public String getApellidos() {
		return apellidos.get();
	}

	public void setApellidos(String apellidos) {
		this.apellidos.set(apellidos);
	}

	public String getDni() {
		return dni.get();
	}

	public void setDni(String dni) {
		this.dni.set(dni);
	}

	public String getFechaNacimiento() {
		return fechaNacimiento.get();
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento.set(fechaNacimiento);
	}

	public String getTelefono() {
		return telefono.get();
	}

	public void setTelefono(String telefono) {
		this.telefono.set(telefono);
	}

	public String getDireccion() {
		return direccion.get();
	}

	public void setDireccion(String direccion) {
		this.direccion.set(direccion);
	}

	@Override
	public String toString() {
		return getNombre() + " " + getApellidos();
	}

}
