package clinica.controladores;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import clinica.modelos.Especialidad;
import clinica.modelos.Medico;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import serviciosMYSQL.ServiceLocator;

public class DirectorMedicoAddControlador implements Initializable {

	@FXML
	private Button cancelButton;
	@FXML
	private Button aceptarButton;

	@FXML
	private TextField patientNameText;

	@FXML
	private TextField patientLastNameText;

	@FXML
	private TextField patientDNIText;

	@FXML
	private TextField patientPhoneText;

	@FXML
	private TextField patientAddressText;

	@FXML
	private DatePicker patientDatePicker;

	@FXML
	private ComboBox<Especialidad> especialidadComboBox;
	@FXML
	private ComboBox<String> userComboBox;

	@FXML
	private Label errorLabel;

	private ArrayList<String> tiposUsuario = new ArrayList<>();

	private Stage avisoStage;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		tiposUsuario.add("Recepcionista");
		tiposUsuario.add("Director");
		tiposUsuario.add("Medico");

		especialidadComboBox.setItems(
				FXCollections.observableArrayList(ServiceLocator.getDirectorServicios().listarEspecialidad()));

		userComboBox.setItems(FXCollections.observableArrayList(tiposUsuario));
	}

	@FXML
	private void onAceptarAddButton(ActionEvent event) {
		boolean agregar = false;
		if (patientNameText.getText().isEmpty()) {
			patientNameText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
			agregar = false;
		} else {
			patientNameText.setStyle("");
			agregar = true;
		}
		if (patientLastNameText.getText().isEmpty()) {
			patientLastNameText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
			agregar = false;
		} else {
			patientNameText.setStyle("");
			agregar = true;
		}
		if (patientDNIText.getText().isEmpty()) {
			patientDNIText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
			agregar = false;
		} else {
			patientNameText.setStyle("");
			agregar = true;
		}
		if (patientDatePicker.getValue() == null || patientDatePicker.getValue().toString().isEmpty()) {
			patientDatePicker.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
		} else {
			patientNameText.setStyle("");
			agregar = true;
		}
		if (patientPhoneText.getText().isEmpty()) {
			patientPhoneText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
			agregar = false;
		} else {
			patientNameText.setStyle("");
			agregar = true;
		}
		if (patientAddressText.getText().isEmpty()) {
			patientAddressText.setStyle("-fx-border-color: red");
			errorLabel.setText("Todos los campos deben estar rellenos");
			agregar = false;
		} else {
			patientNameText.setStyle("");
			agregar = true;

		}
		if (agregar) {
			Medico medico = new Medico();
			medico.setNombre(patientNameText.getText());
			medico.setApellidos(patientLastNameText.getText());
			medico.setDni(patientDNIText.getText());
			medico.setFechaNacimiento(patientDatePicker.getValue().toString());
			medico.setTelefono(patientPhoneText.getText());
			medico.setDireccion(patientAddressText.getText());
			medico.setEspecialidad(especialidadComboBox.getSelectionModel().getSelectedItem());
			medico.setTipoUsuario(userComboBox.getSelectionModel().getSelectedItem());
			try {
				ServiceLocator.getDirectorServicios().addMedico(medico);
				cargarAvisoEmergente("ExitoInsercion");
				Node source = (Node) event.getSource();
				Stage stage = (Stage) source.getScene().getWindow();
				stage.close();
			} catch (SQLException e) {
				cargarAvisoEmergente("ErrorInsercion");
				avisoStage.show();
			}
		}
	}

	@FXML
	private void onCancelarButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

	private void cargarAvisoEmergente(String tipoAviso) {
		try {
			Scene scene = null;
			avisoStage = new Stage();
			avisoStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					avisoStage.close();
				}
			});

			if (tipoAviso.equals("ErrorInsercion")) {
				scene = new Scene(
						new FXMLLoader(getClass().getResource("/clinica/escenas/emergentes/UsuarioExistente.fxml"))
								.load());
			} else if (tipoAviso.equals("ExitoInsercion")) {
				scene = new Scene(
						new FXMLLoader(getClass().getResource("/clinica/escenas/emergentes/MedicoInsertado.fxml"))
								.load());
			}

			avisoStage.setScene(scene);
			avisoStage.setResizable(false);
			avisoStage.setTitle("Error");
			avisoStage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}

	}
}
