package clinica.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import clinica.modelos.Medico;
import clinica.modelos.MedicoSeleccionado;
import clinica.modelos.Paciente;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import serviciosMYSQL.ServiceLocator;

public class DirectorControlador implements Initializable {

	@FXML
	private Button addButton;
	@FXML
	private Button citasButton;
	@FXML
	private Button delButton;
	@FXML
	private Button modButton;

	@FXML
	private Tab medicosTab;

	@FXML
	private Tab pacientesTab;

	@FXML
	private TableView<Medico> medicosTableView;

	@FXML
	private TableView<Paciente> pacientesTableView;

	private TableColumn<Medico, String> tableColumnMedicos;
	private TableColumn<Paciente, String> tableColumnPacientes;

	private Stage agregarStage;
	private Stage modificarStage;
	private Stage avisoStage;
	private Stage citasStage;
	private Scene addMedicoScene;
	private Scene editMedicoScene;
	private Scene citaScene;
	private ObservableList<Paciente> pacientes;
	private ObservableList<Medico> medicos;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		pacientes = FXCollections.observableArrayList();
		medicos = FXCollections.observableArrayList();

		pacientesTab.setOnSelectionChanged(new EventHandler<Event>() {
			@Override
			public void handle(Event t) {
				if (pacientesTab.isSelected()) {
					addButton.setVisible(false);
					modButton.setDisable(true);
					citasButton.setVisible(true);
				}
				actualizarTablas();
			}
		});
		medicosTab.setOnSelectionChanged(new EventHandler<Event>() {
			@Override
			public void handle(Event t) {
				if (medicosTab.isSelected()) {
					addButton.setVisible(true);
					modButton.setDisable(false);
					citasButton.setVisible(false);
				}
				actualizarTablas();
			}
		});

		medicos.addAll(ServiceLocator.getDirectorServicios().listarMedicos());
		medicosTableView.setItems(FXCollections.observableArrayList(medicos));

		pacientes.addAll(ServiceLocator.getDirectorServicios().listarPacientes());
		pacientesTableView.setItems(FXCollections.observableArrayList(pacientes));

		initMedicosTable();
		initPacientesTable();

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initPacientesTable() {
		ArrayList<String> nombreCampos = (ArrayList<String>) ServiceLocator.getDirectorServicios()
				.nombreCamposTablaPacientes();

		int i = 0;
		while (i < nombreCampos.size()) {
			tableColumnPacientes = new TableColumn(nombreCampos.get(i));
			tableColumnPacientes.setCellValueFactory(new PropertyValueFactory<Paciente, String>(nombreCampos.get(i)));

			pacientesTableView.getColumns().add(tableColumnPacientes);
			i++;
		}

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initMedicosTable() {
		ArrayList<String> nombreCampos = (ArrayList<String>) ServiceLocator.getDirectorServicios()
				.nombreCamposTablaMedicos();

		int i = 0;
		while (i < nombreCampos.size() - 1) {
			tableColumnMedicos = new TableColumn(nombreCampos.get(i));
			tableColumnMedicos.setCellValueFactory(new PropertyValueFactory<Medico, String>(nombreCampos.get(i)));
			medicosTableView.getColumns().add(tableColumnMedicos);
			i++;
		}

	}

	@FXML
	private void onAddButtonAction(ActionEvent event) {
		cargarAgregarStage();
		agregarStage.show();

	}

	@FXML
	private void onCitasButtonAction(ActionEvent event) {
		cargarCitas();
		citasStage.show();
	}

	@FXML
	private void onDelButtonAction(ActionEvent event) {
		if (medicosTab.isSelected()) {
			if (medicosTableView.getSelectionModel().getSelectedIndex() == -1) {
				cargarAvisoEmergente();
				avisoStage.show();
			} else {
				ServiceLocator.getDirectorServicios().delMedico(medicosTableView.getSelectionModel().getSelectedItem());
				actualizarTablas();
			}

		} else if (pacientesTab.isSelected()) {
			if (pacientesTableView.getSelectionModel().getSelectedIndex() == -1) {
				cargarAvisoEmergente();
				avisoStage.show();
			} else {
				ServiceLocator.getDirectorServicios()
						.delPaciente(pacientesTableView.getSelectionModel().getSelectedItem());
				actualizarTablas();
			}
		}
	}

	private void actualizarTablas() {
		medicos.clear();
		pacientes.clear();

		medicos.addAll(ServiceLocator.getDirectorServicios().listarMedicos());
		medicosTableView.setItems(FXCollections.observableArrayList(medicos));

		pacientes.addAll(ServiceLocator.getDirectorServicios().listarPacientes());
		pacientesTableView.setItems(FXCollections.observableArrayList(pacientes));

	}

	@FXML
	private void onModButtonAction(ActionEvent event) {
		if (medicosTab.isSelected()) {
			if (medicosTableView.getSelectionModel().getSelectedIndex() == -1) {
				cargarAvisoEmergente();
				avisoStage.show();
			} else {
				MedicoSeleccionado.setPacienteSelecionado(medicosTableView.getSelectionModel().getSelectedItem());
				cargarModificarStage();
				modificarStage.show();
				actualizarTablas();
			}
		}
	}

	private void cargarAgregarStage() {
		try {
			agregarStage = new Stage();
			agregarStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					agregarStage.close();
				}
			});

			addMedicoScene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/Add_Medico.fxml")).load());
			agregarStage.setScene(addMedicoScene);
			agregarStage.setResizable(false);
			agregarStage.setTitle("Agregar M�dico");
			agregarStage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}

	}

	private void cargarModificarStage() {
		try {
			modificarStage = new Stage();
			modificarStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					modificarStage.close();
				}
			});
			editMedicoScene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/Edit_Medico.fxml")).load());
			modificarStage.setScene(editMedicoScene);
			modificarStage.setResizable(false);
			modificarStage.setTitle("Modificar M�dico");
			modificarStage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}

	}

	private void cargarCitas() {
		try {
			citasStage = new Stage();
			citasStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					citasStage.close();
				}
			});

			citaScene = new Scene(new FXMLLoader(getClass().getResource("/clinica/escenas/Recepcionista.fxml")).load());
			citasStage.setScene(citaScene);
			citasStage.setResizable(false);
			citasStage.setTitle("Citas");
			citasStage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}

	}

	private void cargarAvisoEmergente() {
		try {
			avisoStage = new Stage();
			avisoStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					avisoStage.close();
				}
			});

			Scene scene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/emergentes/SeleccionMedico.fxml")).load());
			avisoStage.setScene(scene);
			avisoStage.setResizable(false);
			avisoStage.setTitle("Error");
			avisoStage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}

	}

}
