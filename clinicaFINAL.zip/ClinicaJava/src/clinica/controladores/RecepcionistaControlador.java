package clinica.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import clinica.modelos.Cita;
import clinica.modelos.CitaSeleccionada;
import clinica.modelos.Medico;
import clinica.modelos.Paciente;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import serviciosMYSQL.ServiceLocator;

@SuppressWarnings("rawtypes")
public class RecepcionistaControlador implements Initializable {

	@FXML
	private TableView<Cita> citasTable;

	@FXML
	private TableColumn nombreCell;

	@FXML
	private TableColumn dniCell;

	@FXML
	private TableColumn fechaCell;

	@FXML
	private TableColumn<Cita, String> especialistaCell;

	@FXML
	private Button addButton;
	@FXML
	private Button editButton;
	@FXML
	private Button delButton;
	private Scene addCitaUnoScene;

	private Stage stage;

	private Stage avisoStage;

	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		stage = new Stage();

		citasTable
				.setItems(FXCollections.observableArrayList(ServiceLocator.getRecepcionistaServicios().ListarCitas()));

		nombreCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("nombrePaciente"));
		dniCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("dniPaciente"));
		fechaCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("fecha"));
//		especialistaCell.setCellValueFactory(new PropertyValueFactory<Cita, String>("nombreMedico"));
		especialistaCell.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getMedico().getNombre() + " " + cellData.getValue().getMedico().getApellidos()));

	}

	@FXML
	private void onAddButton(ActionEvent event) {
		cargarScenaUno();
		stage.show();

	}

	@FXML
	private void onDelButton(ActionEvent event) {
	}

	@FXML
	private void onEditButton(ActionEvent event) {
		if (citasTable.getSelectionModel().getSelectedIndex() == -1) {
			cargarAvisoEmergente();
			avisoStage.show();

		} else {
			CitaSeleccionada.setCitaSelecionado(citasTable.getSelectionModel().getSelectedItem());

			cargarEditScena();
			stage.show();

		}

	}

	@FXML
	private void onCancelarButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

	private void cargarScenaUno() {
		try {

			stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					stage.close();
				}
			});

			addCitaUnoScene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/Add_Cita_1.fxml")).load());
			stage.setScene(addCitaUnoScene);
			stage.setResizable(false);
			stage.setTitle("Datos de la cita");
			if (stage.getModality() == Modality.APPLICATION_MODAL) {

			} else
				stage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}
	}

	private void cargarAvisoEmergente() {
		try {
			avisoStage = new Stage();
			avisoStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					avisoStage.close();
				}
			});

			Scene scene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/emergentes/SeleccionMedico.fxml")).load());
			avisoStage.setScene(scene);
			avisoStage.setResizable(false);
			avisoStage.setTitle("Error");
			if (avisoStage.getModality() == Modality.APPLICATION_MODAL) {

			} else
				avisoStage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}

	}

	private void cargarEditScena() {
		try {

			stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent event) {
					stage.close();
				}
			});

			addCitaUnoScene = new Scene(
					new FXMLLoader(getClass().getResource("/clinica/escenas/Edit_Cita_1.fxml")).load());
			stage.setScene(addCitaUnoScene);
			stage.setResizable(false);
			stage.setTitle("Datos de la cita");
			if (stage.getModality() == Modality.APPLICATION_MODAL) {

			} else
				stage.initModality(Modality.APPLICATION_MODAL);

		} catch (IOException e) {
			System.err.println("ERROR");
			e.printStackTrace();
		}
	}
}
