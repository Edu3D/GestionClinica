package clinica.controladores;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import serviciosMYSQL.ServiceLocator;

public class LoginControlador implements Initializable {

	@FXML
	private Button AccederButton;

	@FXML
	private Button CancelarButton;

	@FXML
	private TextField UsuarioText;

	@FXML
	private Label messageErrorLabel;

	@FXML
	private PasswordField PasswordText;

	@FXML
	private ImageView ImgLogin;

	private Scene directorScene;
	private Scene doctorScene;
	private Scene recepcionistaScene;

	private final String DIRECTOR = "DIRECTOR";
	private final String RECEPCIONISTA = "RECEPCIONISTA";
	private final String MEDICO = "MEDICO";

	private Properties props;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		ImgLogin.setImage(new Image("/Imagenes/Login-256.png"));

	}

	@FXML
	private void OnCancelarButton(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

	@FXML
	private void OnAccederButton(ActionEvent event) {
		Acceder(event);
	}

	@FXML
	public void onEnter(KeyEvent e) {
		if (e.getCode().equals(KeyCode.ENTER)) {
			Acceder(e);
		}
	}

	private void Acceder(Event event) {
		String usuario = UsuarioText.getText();
		String password = PasswordText.getText();
		if (ServiceLocator.getUsuarioServicios().checkUserAndPassword(usuario, password)) {

			String user = ServiceLocator.getUsuarioServicios().checkTipoUser(UsuarioText.getText(),
					PasswordText.getText());
			user = user.toUpperCase();
			if (user.equals(DIRECTOR)) {
				try {
					Stage stage;
					stage = new Stage();
					directorScene = new Scene(
							new FXMLLoader(getClass().getResource("/clinica/escenas/Director.fxml")).load());
					stage.setTitle("Director");
					stage.setScene(directorScene);
					stage.show();

					// CARGAMOS USUARIO REGISTRADO EN UN LOG

					generarLog(usuario, user);

					

				} catch (IOException e) {
					e.printStackTrace();
				}

				Node source = (Node) event.getSource();
				Stage thisStage = (Stage) source.getScene().getWindow();
				thisStage.close();
			} else if (user.equals(MEDICO)) {
				try {
					// CARGAMOS USUARIO REGISTRADO EN UN LOG
					generarLog(usuario, user);

					Stage stage;
					stage = new Stage();
					doctorScene = new Scene(
							new FXMLLoader(getClass().getResource("/clinica/escenas/Medico.fxml")).load());
					stage.setTitle("M�dico");
					stage.setScene(doctorScene);
					stage.show();
				} catch (IOException e) {
					e.printStackTrace();
				}

				Node source = (Node) event.getSource();
				Stage thisStage = (Stage) source.getScene().getWindow();
				thisStage.close();
			} else if (user.equals(RECEPCIONISTA)) {
				try {
					// CARGAMOS USUARIO REGISTRADO EN UN LOG
					generarLog(usuario, user);
					Stage stage;
					stage = new Stage();

					recepcionistaScene = new Scene(
							new FXMLLoader(getClass().getResource("/clinica/escenas/Recepcionista.fxml")).load());
					stage.setTitle("Recepcionista");
					stage.setScene(recepcionistaScene);
					stage.show();

				} catch (IOException e) {
					e.printStackTrace();
				}
				Node source = (Node) event.getSource();
				Stage thisStage = (Stage) source.getScene().getWindow();
				thisStage.close();
			} else {
				System.out.println("Ta todo loco");
			}
		} else {
			// ALGO QUE SE TE OCURRA
			PasswordText.clear();
			UsuarioText.setStyle("-fx-border-color: red");
			messageErrorLabel.setText("Usuario o contrase�a incorrectos");

		}
	}

	private void generarLog(String usuario, String tipoUsuario) {
		try {
			props = new Properties();
			File f = new File(System.getProperty("user.home") + "/.clinicaDB/log.properties");
			File d = new File(System.getProperty("user.home") + "/.clinicaDB/");
			if (!d.exists()) {
				d.mkdirs();
			}
			if (!f.exists()) {
				f.createNewFile();

			}
			props.load(new FileReader(f));
			props.setProperty("USER", usuario);
			props.setProperty("Type", tipoUsuario);
			props.store(new FileWriter(f), "�ltimo registro");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
