package clinica.controladores;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;
import java.util.ResourceBundle;

import clinica.modelos.Cita;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Orientation;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import serviciosMYSQL.ServiceLocator;

public class MedicoControlador implements Initializable {

	@FXML
	private ListView<Cita> citasListView;

	@FXML
	private Label nombrePacienteLabel;

	@FXML
	private Label apellidoPacienteLabel;

	@FXML
	private Label dniPacienteLabel;

	@FXML
	private Label fechaNaciemientoPLabel;

	@FXML
	private Label telefonoPacienteLabel;

	@FXML
	private Label direccionPacienteLabel;

	@FXML
	private TextArea observacionesTextArea;

	@FXML
	private ImageView ImgPaciente;

	private String dniMedicoActual;
	
	private Properties props;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		try {
			File f = new File(System.getProperty("user.home") + "/.clinicaDB/log.properties");
			props = new Properties();
			props.load(new FileReader(f));
			setDniMedicoActual(props.getProperty("USER").trim());
			props.store(new FileWriter(f), "�ltimo registro");

		} catch (IOException e) {
			e.printStackTrace();
		}
		
		ArrayList<Cita> citas = (ArrayList<Cita>) ServiceLocator.getMedicoServicios().ListarCitas(getDniMedicoActual());

		ImgPaciente.setImage(new Image("Imagenes/defaultUser.png"));
		citasListView.setOrientation(Orientation.VERTICAL);
		citasListView.setItems(FXCollections.observableArrayList(citas));
		citasListView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Cita>() {

			@Override
			public void changed(ObservableValue<? extends Cita> observable, Cita oldValue, Cita newValue) {
				nombrePacienteLabel.setText(newValue.getPaciente().getNombre());
				apellidoPacienteLabel.setText(newValue.getPaciente().getApellidos());
				dniPacienteLabel.setText(newValue.getPaciente().getDni());
				fechaNaciemientoPLabel.setText(newValue.getPaciente().getFechaNacimiento());
				telefonoPacienteLabel.setText(newValue.getPaciente().getTelefono());
				direccionPacienteLabel.setText(newValue.getPaciente().getDireccion());
				observacionesTextArea.setText(newValue.getPaciente().getObservaciones());
			}

		});

	}

	public String getDniMedicoActual() {
		return dniMedicoActual;
	}

	public void setDniMedicoActual(String dniMedicoActual) {
		this.dniMedicoActual = dniMedicoActual;
	}

}
