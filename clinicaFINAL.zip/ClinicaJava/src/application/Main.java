package application;

import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class Main extends Application {
	Stage primaryStage;

	@Override
	public void start(Stage primaryStage) {
		setUserAgentStylesheet(STYLESHEET_CASPIAN);
		try {

			this.primaryStage = primaryStage;
			this.primaryStage.setTitle("Nombre de la Cl�nica");

			URL url = getClass().getResource("/clinica/escenas/Login.fxml");
			FXMLLoader loader = new FXMLLoader(url);
			Scene scene = new Scene(loader.load());
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.setTitle("Acceso de usuario");
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
